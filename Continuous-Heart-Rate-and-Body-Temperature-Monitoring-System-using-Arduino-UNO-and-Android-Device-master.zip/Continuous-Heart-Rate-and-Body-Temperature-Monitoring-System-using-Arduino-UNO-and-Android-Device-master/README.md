# Hertmate
Patient Heart bit rate monitoring device and Android application
